#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;

bool present(vector <string> terms,string a)
{
for(int i=0;i<terms.size();i++)
{
if(a==terms[i])
	return true;
}
return false;
}

int main()
{
fstream f1("title.txt",ios::in);
fstream f2("terms.txt",ios::out);
vector <string> terms;
while(f1)
{
	string a;
	f1>>a;
	if(a.length()>3 && !present(terms,a))
	{
		terms.push_back(a);
	}
}
sort(terms.begin(),terms.end());
for(int i=0;i<terms.size();i++)
f2<<terms[i]<<"\n";
f1.close();
f2.close();
return 0;
}

