#include <vector>
#include <iostream>
#include <fstream>
#include <string>

int  MAX_DOCUMENTS=100;

using namespace std;

vector <string> tokenize(string time)
{
	vector <string> tokens;
	string temp;
 while (time.find(" ", 0) != std::string::npos)
       {
	 size_t  pos = time.find(" ", 0); //store the position of the delimiter
         temp = time.substr(0, pos);      //get the token
         time.erase(0, pos + 1);          //erase it from the source
         tokens.push_back(temp);                //and put it into the array
       }
       
       tokens.push_back(time);           //the last token is all alone
       return tokens;
}																																																     

vector <int> get_index(vector <string> terms,string temp)
{
	vector <string> tokens=tokenize(temp);
	vector <int> index;
	for(int j=0;j<tokens.size();j++)
	{
		string temp1=tokens[j];
		for(int i=0;i<terms.size();i++)
		{
		if(terms[i]==temp1)
			{
				index.push_back(i);
			}
		}
	}
return index;
}

int main()
{
fstream f1("title.txt",ios::in);
fstream f2("terms.txt",ios::in);
vector <string> titles;
vector <string> terms;
//Read terms first
std::cout<<"indexWords=char(";
string s;
f2>>s;
while(f2)
{
	std::cout<<"'"<<s<<"'";
	terms.push_back(s);
	f2>>s;
	if(f2)
		std::cout<<",";
}
std::cout<<")";
std::cout<<"\n\n\n";
std::cout<<"DocTMatrix=[\n";
//matrix to store frequencies
int arr[terms.size()][MAX_DOCUMENTS];
for(int i=0;i<terms.size();i++)
{
	for(int j=0;j<MAX_DOCUMENTS;j++)
		arr[i][j]=0;
}
int no_of_documents=0;
char temp[150];
f1.getline(temp,150,'\n');
while(f1)
{
	vector <int> index=get_index(terms,temp);
	for(int j=0;j<index.size();j++)
		arr[index[j]][no_of_documents]++;
	no_of_documents++;
	f1.getline(temp,150,'\n');
}
//Now read titles
f1.close();
f2.close();
for(int i=0;i<terms.size();i++)
{
	for(int j=0;j<no_of_documents;j++)
	{
		std::cout<<arr[i][j]<<"\t";
	}
	std::cout<<"\n";
}
std::cout<<"]";
std::cout<<"\n\n";
return 0;
}

