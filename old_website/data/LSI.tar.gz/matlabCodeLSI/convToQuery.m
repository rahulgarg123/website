function answer = convToQuery(query,indexingWords)
 % qeury is a string which will be parsed for the words
 % indexingWords is an array of strings which contains the indexing terms
 % if some word in a query is not there in the index terms then a warning is printed
 % returns the unnormalized array with 1's in position corr to query terms
 
 sizeOfArr = size(indexingWords);
 noOfIndexWords = sizeOfArr(1,1);

 restOfQuery = query;

 answer(noOfIndexWords,1) = 0; % entire array initialized to 0

 while true
 
  [currentWord,restOfQuery] = strtok(restOfQuery);
 
  if isempty(currentWord)
   break;
  end 

  foundWord = false;
  i = 1;
 
  while (foundWord == false & i <= noOfIndexWords)
   if strcmpi(currentWord,deblank(indexingWords(i,:))) 
    foundWord = true;
    answer(i,1) = 1;
   end

   i= i+1;
  end
 
  if(foundWord == false)
    sprintf('Warning :word = %s not found in index terms',currentWord)
  end

 end
