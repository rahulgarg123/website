function answer = documentMatches(query,documentTermMatrix,noOfCategories)
 % query : m*1 matrix where m is the number of index terms,is assumed unnnormalized
 % documentTermMatrix: m*k matrix where m is the no of index terms and k is number of documents need not be normalized
 % noOfCategories: essentially specifies the rank to which reduction takes place
 % returns a k*1 matrix which gives the cos() with each document  
 
 % normalizing the documentTermMatrix
 sizeOfMatrix = size(documentTermMatrix);
 noOfDocs = sizeOfMatrix(1,2);
 noOfTerms= sizeOfMatrix(1,1);
 %for i = 1:noOfDocs
 % documentTermMatrix(:,i) = documentTermMatrix(:,i)/norm(documentTermMatrix(:,i));
 %end
 for i = 1:noOfDocs
  documentTermMatrix(:,i) = documentTermMatrix(:,i)/sum(documentTermMatrix(:,i));
 end
 [q,r] = qr(documentTermMatrix);
 r(noOfCategories+1:noOfTerms,noOfCategories+1:noOfDocs)=zeros(noOfTerms-noOfCategories,noOfDocs-noOfCategories);
 documentsInNewBasis = q(:,1:noOfCategories)'*documentTermMatrix;

 % normalizing the documents in new basis so that we can take cos with query
 for i = 1:noOfDocs
  documentsInNewBasis(:,i) = documentsInNewBasis(:,i)/norm(documentsInNewBasis(:,i));
 end

 %normalize the query
 query = query / norm(query); 

 queryInNewBasis = q(:,1:noOfCategories)' * query;

 %normalize the query in new basis
 queryInNewBasis = queryInNewBasis / norm(queryInNewBasis); 

 documentsInNewBasis
 queryInNewBasis

 answer = queryInNewBasis' * documentsInNewBasis;

 if noOfCategories == 2 
  hold off;
  figure;
	
  xCoordinates = documentsInNewBasis(1,:);
  yCoordinates = documentsInNewBasis(2,:);
 hold on;
 
 xAxisX = -1:0.1:1;

 plot(xAxisX,zeros(1,21));
 plot(zeros(1,21),xAxisX);
 plot(xCoordinates,yCoordinates,'o');
 axis([-1,+1,-1,+1]);

 for i = 1:noOfDocs
   text(xCoordinates(i)+0.01,yCoordinates(i)-0.02,sprintf(' %d',i),'HorizontalAlignment','left');
 end

 hold off;
  hold on;
  plot([queryInNewBasis(1,1);0],[queryInNewBasis(2,1);0],'-k');
  hold off;
end
% elseif noOfCategories == 3

%  xCoordinates = documentsInNewBasis(1,:);
%  yCoordinates = documentsInNewBasis(2,:);
%  zCoordinates = documentsInNewBasis(3,:);
 
%  for i =noOfDocs:-1:1
%   xCoordinates(2*i-1) = xCoordinates(i);
%   xCoordinates(2*i) = 0;
%  end
%  for i =noOfDocs:-1:1 
%   yCoordinates(2*i-1) = yCoordinates(i);
%   yCoordinates(2*i) = 0;
%  end
%  for i =noOfDocs:-1:1 
%   zCoordinates(2*i-1) = zCoordinates(i);
%   zCoordinates(2*i) = 0;
%  end
  
%  plot3([xCoordinates,queryInNewBasis(1,1)],[yCoordinates,queryInNewBasis(2,1)],[zCoordinates,queryInNewBasis(3,1)],'-o')
%  axis([-1,+1,-1,+1,-1,+1]);
 
%  for i = 1:noOfDocs
%    text(xCoordinates(2*i-1)+0.01,yCoordinates(2*i-1)-0.02,zCoordinates(2*i-1),sprintf(' %d',i),'HorizontalAlignment','left');
%  end
%  text(queryInNewBasis(1,1)+0.01,queryInNewBasis(2,1)-0.02,queryInNewBasis(3,1),sprintf('Q'),'HorizontalAlignment','left');
 
% end
