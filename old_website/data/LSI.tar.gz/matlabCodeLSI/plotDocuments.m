function answer = plotDocuments(documentTermMatrix)
 % documentTermMatrix: m*k matrix where m is the no of index terms and k is number of documents need not be normalized
 
 % normalizing the documentTermMatrix
 sizeOfMatrix = size(documentTermMatrix);
 noOfDocs = sizeOfMatrix(1,2);
 for i = 1:noOfDocs
  documentTermMatrix(:,i) = documentTermMatrix(:,i)/sum(documentTermMatrix(:,i));
 end

 [u,s,v] = svd(documentTermMatrix);
 uReduced = u(:,1:2);
 documentsInNewBasis = uReduced' * documentTermMatrix;

 % normalizing the documents in new basis so that we can take cos with query
 for i = 1:noOfDocs
  documentsInNewBasis(:,i) = documentsInNewBasis(:,i)/norm(documentsInNewBasis(:,i));
 end

 xCoordinates = documentsInNewBasis(1,:)
 yCoordinates = documentsInNewBasis(2,:)

 hold on;
 
 xAxisX = -1:0.1:1;

 plot(xAxisX,zeros(1,21));
 plot(zeros(1,21),xAxisX);
 plot(xCoordinates,yCoordinates,'o');
 axis([-1,+1,-1,+1]);

 for i = 1:noOfDocs
   text(xCoordinates(i)+0.01,yCoordinates(i)-0.02,sprintf(' %d',i),'HorizontalAlignment','left');
 end

 hold off;
