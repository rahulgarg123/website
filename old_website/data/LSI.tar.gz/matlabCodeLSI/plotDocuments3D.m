function answer = plotDocuments3D(documentTermMatrix)
 % documentTermMatrix: m*k matrix where m is the no of index terms and k is number of documents need not be normalized
 
 % normalizing the documentTermMatrix
 sizeOfMatrix = size(documentTermMatrix);
 noOfDocs = sizeOfMatrix(1,2);
 for i = 1:noOfDocs
  documentTermMatrix(:,i) = documentTermMatrix(:,i)/sum(documentTermMatrix(:,i));
 end

 [u,s,v] = svd(documentTermMatrix);
 uReduced = u(:,1:3);
 documentsInNewBasis = uReduced' * documentTermMatrix;

 % normalizing the documents in new basis so that we can take cos with query
 for i = 1:noOfDocs
  documentsInNewBasis(:,i) = documentsInNewBasis(:,i)/norm(documentsInNewBasis(:,i));
 end

 xCoordinates = documentsInNewBasis(1,:);
 yCoordinates = documentsInNewBasis(2,:);
 zCoordinates = documentsInNewBasis(3,:);

 for i =noOfDocs:-1:1
  xCoordinates(2*i-1) = xCoordinates(i);
  xCoordinates(2*i) = 0;
 end
 for i =noOfDocs:-1:1 
  yCoordinates(2*i-1) = yCoordinates(i);
  yCoordinates(2*i) = 0;
 end
 for i =noOfDocs:-1:1 
  zCoordinates(2*i-1) = zCoordinates(i);
  zCoordinates(2*i) = 0;
 end
 
 xAxisX = -1:0.1:1;


 plot3(xAxisX,zeros(1,21),zeros(1,21))
 plot3(zeros(1,21),xAxisX,zeros(1,21))
 plot3(zeros(1,21),zeros(1,21),xAxisX)
 plot3(xCoordinates,yCoordinates,zCoordinates,'-o')
 axis([-1,+1,-1,+1,-1,+1]);

 for i = 1:noOfDocs
   text(xCoordinates(2*i-1)+0.01,yCoordinates(2*i-1)-0.02,zCoordinates(2*i-1),sprintf(' %d',i),'HorizontalAlignment','left');
 end

