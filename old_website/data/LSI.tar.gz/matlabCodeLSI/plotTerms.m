function answer = plotDocuments(documentTermMatrix)
 % documentTermMatrix: m*k matrix where m is the no of index terms and k is number of documents need not be normalized
 
 % normalizing the documentTermMatrix
 sizeOfMatrix = size(documentTermMatrix);
 noOfDocs = sizeOfMatrix(1,2);
 noOfTerms = sizeOfMatrix(1,1);
 for i = 1:noOfDocs
  documentTermMatrix(:,i) = documentTermMatrix(:,i)/sum(documentTermMatrix(:,i));
 end

 [u,s,v] = svd(documentTermMatrix);
 vReduced = v(:,1:2);
 termsInNewBasis =  documentTermMatrix * vReduced;
 termsInNewBasis = termsInNewBasis';

 % normalizing the terms so that we can see their angles properly
 for j = 1:noOfTerms
  termsInNewBasis(:,j) = 0.5*(termsInNewBasis(:,j)/norm(termsInNewBasis(:,j)));
 end

 xCoordinates = termsInNewBasis(1,:);
 yCoordinates = termsInNewBasis(2,:);

 hold on;
 
 xAxisX = -1:0.1:1;

 plot(xAxisX,zeros(1,21));
 plot(zeros(1,21),xAxisX);
 plot(xCoordinates,yCoordinates,'+r');
 axis([-1,+1,-1,+1]);

 for i = 1:noOfTerms
   text(xCoordinates(i)+0.01,yCoordinates(i)-0.02,sprintf(' %d',i),'HorizontalAlignment','left');
 end

