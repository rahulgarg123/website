DocTMatrix = [
% cs      maths    ee
1 1 1 0  0 0 0 0  0 0 0 0 % cs 
1 1 1 1  0 0 0 0  0 1 0 0 % cs
0 1 1 1  0 0 0 0  0 0 0 0 % cs
1 1 0 1  0 1 0 0  0 0 0 0 % cs
0 1 1 0  1 0 1 0  0 0 0 0 % t5 common to cs and maths
0 0 0 0  1 1 1 0  1 0 1 1 % t6 common to maths and ee
0 0 0 0  1 1 1 1  0 0 0 0 % maths
0 0 0 1  1 1 0 1  0 0 0 0 % maths
0 0 0 0  0 1 1 1  1 0 0 0 % maths
0 0 0 0  1 0 0 0  1 1 1 1 % ee
0 0 1 0  0 0 0 0  1 1 0 1 % ee
0 0 0 0  0 0 0 0  1 0 1 1 % ee
0 0 0 0  0 0 0 0  1 1 1 0 % ee 
]

% t6 common to both maths and ee but t10 is a ee term so ee docs should come before the bogus maths doc = d5
queryPolySemy = [0 0 0 0 0 1 0 0 0 1 0 0 0]'

% t4 is a cs term but appears by chance in d6, but we report all cs terms before that
querySynonymy = [0 0 0 1 0 0 0 0 0 0 0 0 0]'

% t11 is a ee term but appears by chance in d3, but we report all ee terms before that
% note that this works well in 3 dimensions but not in 2 dimensions
querySynonymy2 = [0 0 0 0 0 0 0 0 0 0 1 0 0]'
