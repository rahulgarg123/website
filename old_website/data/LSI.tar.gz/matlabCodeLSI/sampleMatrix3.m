DocTMatrix = [
% cs     maths
1 1 1 0 0 0 0 0 % cs
1 1 1 1 0 0 0 0 % cs
1 1 1 1 0 0 0 0 % cs
1 1 1 1 0 0 0 0 % cs
1 1 1 1 0 0 0 0 % cs
1 1 1 1 0 0 0 0 % cs
1 1 1 1 0 0 0 0 % cs
0 1 1 1 0 0 0 0 % cs
1 1 0 1 0 1 0 0 % cs
0 1 1 0 1 1 0 0 % both cs and maths
0 0 0 0 1 1 1 0 % maths
0 0 0 0 1 1 1 1 % maths
0 0 0 1 1 1 0 1 % maths
0 0 0 0 0 1 1 1 % maths
0 0 0 0 1 1 1 1 % maths
0 0 0 0 1 1 1 1 % maths
0 0 0 0 1 1 1 1 % maths
]

% A polysemy demonstrating query: t5 appears both in cs and math terms, but t5 along with
% t4 means a cs document, so searching for that return d4 before the spurious d6
queryPolySemy = [ 0 0 1 1 0 0 0 0]'

% Synonymy demonstrating qeury: t4 search gives d3 before the document d6,bcos of synonymy
querySynonymy = [0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0]'

% Synonymy demonstrating qeury: t8 search gives d7 before the document d4,bcos of synonymy
querySynonymy2 = [ 0 0 0 0 0 0 1 0]'
