function [answer,answer1]=deflate(A)

% top level function to recursively call shifted QR iterations
% the function also performs necessary deflations

TERMINATION_VAL=10^-2;
siz=size(A);
m=siz(1);
if( m==1 )
	answer=A;
	answer1=0;
else

[A1 no_of_iterations]=shifted_qr(A,TERMINATION_VAL); %do a qr ieration on A till one of the subdiagonal entries converge to zero

%now find an index about which the deflation has to be donea

for i=m:-1:2
	if(abs(A1(i,i-1))<TERMINATION_VAL)
	%disp(strcat('Deflation about',num2str(i)))
	%waitforbuttonpress
	[A11 no_of_iterations11]=deflate(A1(1:i-1,1:i-1));
	[A22 no_of_iterations22]=deflate(A1(i:m,i:m));
	answer(1:i-1,1:i-1)=A11;
	answer(i:m,i:m)=A22;
	answer1=no_of_iterations11+no_of_iterations22+no_of_iterations;
	break;
	end
end

end
