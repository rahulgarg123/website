function [answer1,answer2]=hessenberg(A)

%function to calculate hessenberg form of the matrix

S=size(A);
m=S(1);                                   %size of A
Q_cumulative=eye(m);
for k=1:m-2 
	x=A(k+1:m,k);
	vec_size=size(x);
	e1=zeros(vec_size(1),1);
	e1(1)=1;
	v=sign(x(1))*norm(x)*e1+x;
	v=v/norm(v);
	A(k+1:m,k:m)=A(k+1:m,k:m)-2*v*(v'*A(k+1:m,k:m));
	A(1:m,k+1:m)=A(1:m,k+1:m)-2*(A(1:m,k+1:m)*v)*v';
	A(k+2:m,k)=zeros(vec_size(1)-1,1);
	Q=eye(m);
	Q(k+1:m,k+1:m)=eye(vec_size(1))-2*v*v';
	Q_cumulative=Q*Q_cumulative;
end
answer1=A;
answer2=Q_cumulative;
