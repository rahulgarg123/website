function [answer1 answer2]=unshifted_qr(A,TERMINATION_VAL)

%function to calculate eigenvalues using unshifted qr algo
%input should be a hessenberg matrix preferably

siz=size(A);
m=siz(1); %size of matrix A
no_of_iterations=0;
flag=false;
while flag==false  %iterate 
	%pick a shift
	u=A(m,m);
	% subtracting UI to A
	for i=1:m
		A(i,i)=A(i,i)-u;
	end
	[Q R]=qr(A);
	A=R*Q;
	% adding UI to A
	for i=1:m
		A(i,i)=A(i,i)+u;
	end
        %waitforbuttonpress	
        no_of_iterations=no_of_iterations+1;
	%Now look for smallest subdiagonal entry 
	for i=m:-1:2
		if (abs(A(i,i-1))<TERMINATION_VAL)
		flag=true;
		i=1;
		end
	end
end
answer1=A;
answer2=no_of_iterations;
