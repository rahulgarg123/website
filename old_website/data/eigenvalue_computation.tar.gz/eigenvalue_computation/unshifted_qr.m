function [answer1 answer2]=unshifted_qr(A)

%function to calculate eigenvalues using unshifted qr algo
%input should be a hessenberg matrix preferably

siz=size(A);
m=siz(1); %size of matrix A
last_entry=1;
no_of_iterations=0;
while abs(last_entry)>=10^-12  %iterate 
	[Q R]=qr(A);
	A=R*Q;
	last_entry=A(2,1);
        no_of_iterations=no_of_iterations+1;
end
answer1=A;
answer2=no_of_iterations;
